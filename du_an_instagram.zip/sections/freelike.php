<section class="page-section" id="freelikes">

    <div class="container">
        <div class="row">
            <div class="free-container fadeInUp duration-1-5s" align="center">
                <h2 class="section-title">FREE INSTAGRAM LIKES</h2>

                <form method="post">

                    <input class="form-control mb-20" type="text" id="post-link" placeholder="Post link" required>
                    <br>

                    <span>
                        <input type="checkbox" name="follow" value="" disabled>
                        Free 10 followers (only for
                        <a href="#">login users</a>
                        )
                    </span>
                    <br>

                    <input class="btn btn-border btn-round btn-medium bgr-dark" id="free-order" type="submit" value="NHẬN MIỄN PHÍ">


                </form>
            </div>

        </div>

    </div>

</section>