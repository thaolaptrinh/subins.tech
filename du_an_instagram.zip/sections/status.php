<section class="page bgray" id="status">
    <div class="container status">
        <div class="infos">
            <div class="infos-detail">
                <i class="fa-solid fa-user-plus icon-infos" style="color: #10A0DE;"></i>
                <div class="infos-text">
                    <h4 class="heading-large" style="color: #10A0DE;">3 558</h4>
                    <p class="text-16px">Người dùng</p>
                </div>
            </div>

            <div class="infos-detail">
                <i class="fa-solid fa-list icon-infos" style="color: #72BD35;"></i>
                <div class="infos-text">
                    <h4 class="heading-large" style="color: #72BD35;">20 531</h4>
                    <p class="text-16px">Đơn đặt hàng</p>
                </div>
            </div>
            <div class="infos-detail">
                <i class="fa-solid fa-list-check icon-infos" style="color: #F74B4B;"></i>
                <div class="infos-text">
                    <h4 class="heading-large" style="color: #F74B4B;">79 377</h4>
                    <p class="text-16px">Đơn thành công</p>
                </div>
            </div>

        </div>
    </div>

</section>