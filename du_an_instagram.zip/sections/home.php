<section class="page-section" id="home">

    <div class="hero">
        <div class="hero-text">
            NHANH CHÓNG | TIN CẬY | AN TOÀN
        </div>

        <h1 class="hero-heading">
            TLT PANEL №1
        </h1>

        <div class="hero-btn">
            <a href="index.php?page=login" class="btn btn-medium btn-round btn-border">
                <i class="fa-solid fa-right-from-bracket"></i>
                ĐĂNG NHẬP / ĐĂNG KÝ</a>


            <a href="#" class="btn btn-medium btn-round btn-border">
                <i class="fa-solid fa-heart"></i>
                LIKES MIỄN PHÍ</a>

            <a href="#" class="btn btn-medium btn-round btn-border">
                <i class="fa-solid fa-gem"></i>
                DANH SÁCH DỊCH VỤ</a>
        </div>

        <div class="hero-scroll-arrow">

            <div><i class="fa fa-chevron-down arrow" aria-hidden="true"></i></div>
            <div><i class="fa fa-chevron-down arrow" aria-hidden="true"></i></div>
            <div><i class="fa fa-chevron-down arrow" aria-hidden="true"></i></div>

        </div>

    </div>


</section>