<section class="page-section bgray" id="reviews">
    <h2 class="section-title">REVIEWS</h2>

    <div class="container">

        <div class="row">
            <div class="col">
                <div class="review-container">
                    <img src="./images/anna.jpg" alt="" class="img-circle" style="width: 150px; padding-bottom: 10px;">

                    <blockquote class="testimonial">
                        <p>Cảm ơn subins.tech vì sản phẩm của bạn! Chất lượng công việc rất cao và hỗ trợ tư
                            vấn
                            nhiệt tình! Sau khi sử dụng, lượt theo dõi tăng lên nhanh chóng, điều mà tôi
                            không
                            thể ngờ tới! Bình luận liên tục, chỉ có thời gian để trả lời và điều quan trọng,
                            đơn
                            đặt hàng thực, số lượng không ngừng tăng lên! Cảm ơn một lần nữa! Chúng tôi hy
                            vọng
                            khách hàng của bạn trong một thời gian rất dài! Tôi sẽ giới thiệu bạn cho tất cả
                            và
                            chúc bạn phát triển!</p>

                        <footer class="testimonial-author">-- BÁNH BÈO --</footer>
                    </blockquote>

                </div>

            </div>

        </div>

        <div class="text-center all-reviews">
            <a href="#">ALL REVIEW</a>
        </div>

    </div>

</section>