<section class="page-section bgray" id="marketing">

    <div class="container">

        <div class="row">
            <div class="mar-container">

                <div class="col">
                    <img src="./images/iph.png" alt="load" class="img-phone fadeInLeft duration-1-5s">
                </div>


                <div class="col">
                    <div class="media fadeInRight duration-1-5s">

                        <div class="media-body">
                            <img src="./images/usersglav.png" alt="" class="media-ico">
                            <div class="media-text  ">
                                <h3 class="text-20px">Người theo dõi trên Instagram</h3>
                                <p>Người theo dõi có tác động lớn đến xếp hạng và chất lượng của tài khoản.
                                    Thứ
                                    hạng
                                    của hồ sơ trong tìm kiếm người dùng khác phụ thuộc vào số lượng người
                                    theo
                                    dõi
                                    và khơi dậy lòng tin của người đã đến trang của bạn. Tỷ lệ người theo
                                    dõi
                                    càng
                                    cao, thì càng có nhiều cơ hội để một vị khách ngẫu nhiên thể hiện sự
                                    quan
                                    tâm và
                                    đăng ký!</p>
                            </div>
                        </div>


                        <div class="media-body mt-20">
                            <img src="./images/likeglav.png" alt="" class="media-ico">
                            <div class="media-text">
                                <h3 class="text-20px">Lượt thích trên Instagram</h3>
                                <p>Để đưa một bài đăng lên top theo # hashtag hoặc các truy vấn đơn giản, nó
                                    cần
                                    một số lượt thích nhất định. Việc nhận được lượt thích sẽ cho phép các
                                    bài
                                    đăng đứng đầu tìm kiếm trong một thời gian dài và đảm bảo rằng chúng sẽ
                                    được
                                    đưa vào các đề xuất của người dùng instagram. Một số lượng lớn lượt
                                    thích
                                    giúp phân biệt bài đăng của bạn với những người khác và thu hút rất
                                    nhiều sự
                                    chú ý, và khi sử dụng nội dung chất lượng cao, khả năng có thêm đăng ký
                                    từ
                                    những người quan tâm sẽ tăng lên.</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</section>