<main>

    <?php
    include "./sections/home.php";
    include "./sections/status.php";
    include "./sections/about.php";
    include "./sections/freelike.php";
    include "./sections/marketing.php";
    include "./sections/slider.php";
    include "./sections/affiliate.php";
    include "./sections/reviews.php";
    ?>

</main>